var APP_DATA = {
  "scenes": [
    {
      "id": "0-img_0006",
      "name": "IMG_0006",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.5358176389601024,
          "pitch": 0.4005055857775517,
          "rotation": 0,
          "target": "1-img_0006"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -3.0792325995473124,
          "pitch": 0.4425461136185387,
          "title": "Title",
          "text": "Text"
        }
      ]
    },
    {
      "id": "1-img_0006",
      "name": "IMG_0006",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -2.8339452487834134,
        "pitch": 0.40409467871397986,
        "fov": 1.3419674740723089
      },
      "linkHotspots": [
        {
          "yaw": 2.506248666035411,
          "pitch": 0.4386866477327267,
          "rotation": 0,
          "target": "1-img_0006"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.8438762687834167,
          "pitch": 0.4140256987139832,
          "title": "testi",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
